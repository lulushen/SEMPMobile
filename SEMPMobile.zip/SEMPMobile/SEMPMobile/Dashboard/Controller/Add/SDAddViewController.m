//
//  SDAddViewController.m
//  SempMobile
//
//  Created by 上海数聚 on 16/7/11.
//  Copyright © 2016年 上海数聚. All rights reserved.
//

#import "SDAddViewController.h"
#import "SDAddCollectionViewCell.h"

@interface SDAddViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

// collection
@property (nonatomic , strong)UICollectionView * FirstCollectionView;

@property (nonatomic , strong)UICollectionView * TwoCollectctionView;

@property (nonatomic , strong)NSMutableArray * dataArray;

@property (nonatomic , strong)NSMutableArray * array2;


@end

@implementation SDAddViewController

// 懒加载
- (NSMutableArray *)dataArray
{
    if (_dataArray == nil) {
        
        _dataArray = [NSMutableArray array];
    }
    
    return _dataArray;
}
- (NSMutableArray *)array2
{
    if (_array2 == nil) {
        
        _array2 = [NSMutableArray array];
    }
    
    return _array2;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.userInteractionEnabled = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.title = @"Add";

    self.tabBarController.tabBar.hidden = YES;
   
    _dataArray = [NSMutableArray  arrayWithObjects:@"a",@"b",@"c",@"d",@"e",@"f",@"g",@"h",@"r",@"i", nil];
    
    _array2 = [NSMutableArray  arrayWithObjects:@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13", nil];

    // 自定义返回按钮LeftButtonItme
    [self makeLeftButtonItme];
    
    // 定义tabelView
    [self makeCollectionView];
    
    // Do any additional setup after loading the view.
}
- (void)makeLeftButtonItme
{
    UIImage * backImage = [UIImage imageNamed:@"back.png"];
    CGRect backframe = CGRectMake(0, 0, 54*KWidth6scale, 30*KHeight6scale);
    UIButton * backButton = [[UIButton alloc] initWithFrame:backframe];
    [backButton setBackgroundImage:backImage forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(backButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem * leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
    self.navigationItem.leftBarButtonItem = leftBarButtonItem;
   
}
- (void)backButtonClick:(UIButton *)button {
    
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)makeCollectionView
{
    
    UICollectionViewLayout * layout = [[UICollectionViewLayout alloc] init];
    
    _FirstCollectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, Kwidth, Kheight/3.0) collectionViewLayout:layout];
    
    
    _FirstCollectionView.backgroundColor = [UIColor cyanColor];
    
    _FirstCollectionView.tag = 1;
    
    _FirstCollectionView.delegate = self;
    
    _FirstCollectionView.dataSource = self;
    
//    _FirstCollectionView.userInteractionEnabled = YES;
    
    [self.view addSubview:_FirstCollectionView];
    
    _TwoCollectctionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(_FirstCollectionView.frame), Kwidth, Kheight*2/3.0)collectionViewLayout:layout];
    
    _TwoCollectctionView.backgroundColor = [UIColor redColor];
    
    _TwoCollectctionView.tag = 2;
    
    _TwoCollectctionView.delegate = self;
    
    _TwoCollectctionView.dataSource = self;
    
    [self.view addSubview:_TwoCollectctionView];
    
    [_FirstCollectionView  registerClass:[SDAddCollectionViewCell class] forCellWithReuseIdentifier:@"addcell"];
    [_FirstCollectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"header"];

    [_TwoCollectctionView registerClass:[SDAddCollectionViewCell class] forCellWithReuseIdentifier:@"addcell"];

    
    
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    NSLog(@"_dataArray  Count : %ld",_dataArray.count);
    NSLog(@"_dataArray  Count : %ld",_array2.count);

    if (collectionView.tag == 1) {
        return _dataArray.count;
    } else {
        return _array2.count;
    }

}
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    SDAddCollectionViewCell * addcell = [collectionView dequeueReusableCellWithReuseIdentifier:@"addcell" forIndexPath:indexPath];
    
    if (collectionView.tag == 1) {
        for (NSString * str  in _dataArray) {
            
            addcell.titleLab.text = str;
            NSLog(@"addcell  label text: %@",addcell.titleLab.text);
            
        }

    }else{
        for (NSString * str  in _array2) {
            
            addcell.titleLab.text = str;
            NSLog(@"addcell  label text: %@",addcell.titleLab.text);
            
        }
        
        
        
    }
    
    
    
    
    return addcell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    if (collectionView.tag == 1) {
        if([kind isEqualToString:UICollectionElementKindSectionHeader])
        {
            UICollectionReusableView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:@"header" forIndexPath:indexPath];
            if(headerView == nil)
            {
                headerView = [[UICollectionReusableView alloc] init];
            }
            headerView.backgroundColor = [UIColor grayColor];
            
            return headerView;
        }else if([kind isEqualToString:UICollectionElementKindSectionFooter])
        {
            UICollectionReusableView *footerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:@"fooder" forIndexPath:indexPath];
            if(footerView == nil)
            {
                footerView = [[UICollectionReusableView alloc] init];
            }
            footerView.backgroundColor = [UIColor lightGrayColor];
            
            return footerView;
        }

    }
    
    return nil;
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    return (CGSize){Kwidth,44};
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
