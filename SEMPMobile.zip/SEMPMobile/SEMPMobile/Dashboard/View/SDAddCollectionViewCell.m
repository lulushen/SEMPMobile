//
//  SDAddCollectionViewCell.m
//  SEMPMobile
//
//  Created by 上海数聚 on 16/7/20.
//  Copyright © 2016年 上海数聚. All rights reserved.
//

#import "SDAddCollectionViewCell.h"

@implementation SDAddCollectionViewCell
-(id)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    if (self) {
        _titleLab = [[UILabel alloc] init];
        _titleLab.backgroundColor = [UIColor grayColor];
        
        [self.contentView addSubview:_titleLab];
    }
    return self;
}

- (void)layoutSubviews
{
    
    [super layoutSubviews];
    
    _titleLab.frame = CGRectMake(0, 0, CGRectGetWidth(self.contentView.frame), CGRectGetHeight(self.contentView.frame));
    
    
    
}

@end
