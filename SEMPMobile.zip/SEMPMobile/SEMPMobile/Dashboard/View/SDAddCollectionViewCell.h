//
//  SDAddCollectionViewCell.h
//  SEMPMobile
//
//  Created by 上海数聚 on 16/7/20.
//  Copyright © 2016年 上海数聚. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SDAddCollectionViewCell : UICollectionViewCell

@property (nonatomic , strong)UILabel * titleLab;

@end
