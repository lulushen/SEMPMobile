//
//  SDRTSectionHeaderViewController.h
//  SEMPMobile
//
//  Created by 上海数聚 on 16/7/13.
//  Copyright © 2016年 上海数聚. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface SDRTSectionHeaderViewController : UIViewController
//分区头部上的标题button
@property (nonatomic , strong)UIButton * sectionTitleButton;
// 分区头部上的moreButton
@property (nonatomic , strong)UIButton * moreButton;
@end
